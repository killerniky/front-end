Open Wifi Antwerpen.

Deze app laat alle locaties zienwaar open wifi van Antwerpen is voorzien. 
Je kunt de locaties aanpassen en je kunt er zelf toevoegen en verwijderen.

De app kun je starten door de api file via npm run start te runnen en dan tegelijk de studenten-ajax app.

De loading animatie kunt u vinden in de map Studenten-Ajax/src/components/Locaties/Loading-Anim.svg

